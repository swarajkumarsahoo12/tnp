import React from "react";
import { Link } from "react-router-dom";
import { useStudent } from "../context/StudentContext";

export default function Home() {
  const { student } = useStudent();

  return (
    <div style={{ padding: "32px 24px", maxWidth: "640px", margin: "0 auto" }}>
      <h1 style={{ fontSize: "22px", fontWeight: 500, marginBottom: "8px" }}>
        Welcome back, {student.name.split(" ")[0]}
      </h1>
      <p style={{ color: "#6b7280", marginBottom: "24px" }}>
        You're enrolled in {student.enrolledCourses.length} course
        {student.enrolledCourses.length === 1 ? "" : "s"}. Head over to the
        courses page to explore more.
      </p>

      <div
        style={{
          background: "#fff",
          border: "1px solid #e5e7eb",
          borderRadius: "12px",
          padding: "16px 20px",
          marginBottom: "24px",
        }}
      >
        <p style={{ fontSize: "13px", color: "#6b7280", margin: "0 0 4px" }}>
          Logged in as
        </p>
        <p style={{ fontWeight: 500, margin: 0 }}>{student.name}</p>
        <p style={{ fontSize: "13px", color: "#6b7280", margin: 0 }}>
          {student.email}
        </p>
      </div>

      <Link
        to="/courses"
        style={{
          display: "inline-block",
          padding: "10px 18px",
          background: "#1d4ed8",
          color: "#fff",
          borderRadius: "6px",
          textDecoration: "none",
          fontSize: "14px",
          fontWeight: 500,
        }}
      >
        Browse courses
      </Link>
    </div>
  );
}
