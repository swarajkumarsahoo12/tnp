import React from "react";
import { Link } from "react-router-dom";
import courses from "../data/courses";
import { useStudent } from "../context/StudentContext";

export default function Courses() {
  const { student } = useStudent();

  return (
    <div style={{ padding: "32px 24px", maxWidth: "640px", margin: "0 auto" }}>
      <h1 style={{ fontSize: "22px", fontWeight: 500, marginBottom: "20px" }}>
        Available courses
      </h1>

      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        {courses.map((course) => {
          const isEnrolled = student.enrolledCourses.includes(course.id);
          return (
            <Link
              key={course.id}
              to={`/course/${course.id}`}
              style={{
                display: "block",
                background: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "12px",
                padding: "16px 20px",
                textDecoration: "none",
                color: "inherit",
              }}
            >
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                }}
              >
                <p style={{ fontWeight: 500, margin: 0 }}>{course.title}</p>
                {isEnrolled && (
                  <span
                    style={{
                      fontSize: "12px",
                      color: "#15803d",
                      background: "#dcfce7",
                      padding: "2px 8px",
                      borderRadius: "999px",
                    }}
                  >
                    Enrolled
                  </span>
                )}
              </div>
              <p style={{ fontSize: "13px", color: "#6b7280", margin: "4px 0 0" }}>
                {course.instructor} &middot; {course.duration}
              </p>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
