import React from "react";

export default function About() {
  return (
    <div style={{ padding: "32px 24px", maxWidth: "640px", margin: "0 auto" }}>
      <h1 style={{ fontSize: "22px", fontWeight: 500, marginBottom: "12px" }}>
        About this app
      </h1>
      <p style={{ color: "#374151", lineHeight: 1.6 }}>
        This is a small Student Course Management application built with
        React. It demonstrates client-side routing with React Router,
        dynamic course detail pages, and shared student state managed
        through the Context API — all using functional components and hooks.
      </p>
    </div>
  );
}
