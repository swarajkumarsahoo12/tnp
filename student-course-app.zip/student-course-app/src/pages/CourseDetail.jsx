import React from "react";
import { useParams, Link } from "react-router-dom";
import courses from "../data/courses";
import { useStudent } from "../context/StudentContext";

export default function CourseDetail() {
  const { id } = useParams(); // reads the dynamic :id segment from the URL
  const { student, enrollInCourse } = useStudent();

  const course = courses.find((c) => c.id === id);

  if (!course) {
    return (
      <div style={{ padding: "32px 24px", maxWidth: "640px", margin: "0 auto" }}>
        <p>Course not found.</p>
        <Link to="/courses">Back to courses</Link>
      </div>
    );
  }

  const isEnrolled = student.enrolledCourses.includes(course.id);

  return (
    <div style={{ padding: "32px 24px", maxWidth: "640px", margin: "0 auto" }}>
      <Link
        to="/courses"
        style={{ fontSize: "13px", color: "#1d4ed8", textDecoration: "none" }}
      >
        ← Back to courses
      </Link>

      <h1 style={{ fontSize: "22px", fontWeight: 500, margin: "12px 0 4px" }}>
        {course.title}
      </h1>
      <p style={{ fontSize: "13px", color: "#6b7280", marginBottom: "20px" }}>
        {course.instructor} &middot; {course.duration}
      </p>

      <p style={{ color: "#374151", lineHeight: 1.6, marginBottom: "24px" }}>
        {course.description}
      </p>

      {isEnrolled ? (
        <span
          style={{
            display: "inline-block",
            padding: "10px 18px",
            background: "#dcfce7",
            color: "#15803d",
            borderRadius: "6px",
            fontSize: "14px",
            fontWeight: 500,
          }}
        >
          You're enrolled in this course
        </span>
      ) : (
        <button
          onClick={() => enrollInCourse(course.id)}
          style={{
            padding: "10px 18px",
            background: "#1d4ed8",
            color: "#fff",
            border: "none",
            borderRadius: "6px",
            fontSize: "14px",
            fontWeight: 500,
            cursor: "pointer",
          }}
        >
          Enroll now
        </button>
      )}
    </div>
  );
}
