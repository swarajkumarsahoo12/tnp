import React, { createContext, useContext, useState } from "react";

// Context object that will hold shared student data
const StudentContext = createContext(null);

// Provider component — wraps the app and makes student info available
// to any component that calls useStudent(), without prop drilling.
export function StudentProvider({ children }) {
  const [student, setStudent] = useState({
    name: "Swaraj Kumar",
    email: "swarajkumarsahoo08@gmail.com",
    enrolledCourses: ["react-101", "js-201"],
  });

  const enrollInCourse = (courseId) => {
    setStudent((prev) => {
      if (prev.enrolledCourses.includes(courseId)) return prev;
      return { ...prev, enrolledCourses: [...prev.enrolledCourses, courseId] };
    });
  };

  return (
    <StudentContext.Provider value={{ student, setStudent, enrollInCourse }}>
      {children}
    </StudentContext.Provider>
  );
}

// Custom hook for easy access to the context in any component
export function useStudent() {
  const context = useContext(StudentContext);
  if (!context) {
    throw new Error("useStudent must be used within a StudentProvider");
  }
  return context;
}
