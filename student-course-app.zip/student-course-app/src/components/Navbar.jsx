import React from "react";
import { NavLink } from "react-router-dom";

export default function Navbar() {
  const linkStyle = ({ isActive }) => ({
    padding: "8px 14px",
    borderRadius: "6px",
    textDecoration: "none",
    fontSize: "14px",
    fontWeight: 500,
    color: isActive ? "#1d4ed8" : "#374151",
    background: isActive ? "#e6f1fb" : "transparent",
  });

  return (
    <nav
      style={{
        display: "flex",
        gap: "8px",
        padding: "14px 24px",
        borderBottom: "1px solid #e5e7eb",
        background: "#fff",
      }}
    >
      <NavLink to="/" style={linkStyle} end>
        Home
      </NavLink>
      <NavLink to="/courses" style={linkStyle}>
        Courses
      </NavLink>
      <NavLink to="/about" style={linkStyle}>
        About
      </NavLink>
    </nav>
  );
}
