import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { StudentProvider } from "./context/StudentContext";
import Navbar from "./components/Navbar";
import Home from "./pages/Home";
import Courses from "./pages/Courses";
import CourseDetail from "./pages/CourseDetail";
import About from "./pages/About";

export default function App() {
  return (
    // StudentProvider makes shared student data available to every page
    // below it without passing props down manually.
    <StudentProvider>
      <BrowserRouter>
        <div style={{ minHeight: "100vh", background: "#f4f5f7", fontFamily: "sans-serif" }}>
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/courses" element={<Courses />} />
            {/* Dynamic route: matches /course/react-101, /course/js-201, etc. */}
            <Route path="/course/:id" element={<CourseDetail />} />
            <Route path="/about" element={<About />} />
          </Routes>
        </div>
      </BrowserRouter>
    </StudentProvider>
  );
}
