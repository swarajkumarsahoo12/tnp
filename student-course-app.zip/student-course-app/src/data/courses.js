// Shared course data. In a real app this would come from an API.
const courses = [
  {
    id: "react-101",
    title: "React Fundamentals",
    instructor: "Priya Nair",
    duration: "6 weeks",
    description:
      "An introduction to React covering components, props, state, and hooks.",
  },
  {
    id: "js-201",
    title: "Advanced JavaScript",
    instructor: "Arjun Mehta",
    duration: "8 weeks",
    description:
      "Deep dive into closures, async programming, and modern ES6+ features.",
  },
  {
    id: "css-150",
    title: "Modern CSS Layouts",
    instructor: "Kavya Reddy",
    duration: "4 weeks",
    description:
      "Master Flexbox, Grid, and responsive design principles for real projects.",
  },
];

export default courses;
