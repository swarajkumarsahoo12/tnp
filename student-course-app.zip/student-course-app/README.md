# Student Course Management App

A small React app demonstrating routing (React Router) and shared state
(Context API).

## Structure
- `src/pages/Home.jsx` — welcome page, reads student info from Context
- `src/pages/Courses.jsx` — lists all courses, links to dynamic routes
- `src/pages/CourseDetail.jsx` — dynamic route `/course/:id`, shows one course and lets the student enroll
- `src/pages/About.jsx` — static about page
- `src/context/StudentContext.jsx` — Context API provider + `useStudent()` hook
- `src/components/Navbar.jsx` — navigation using `NavLink`
- `src/data/courses.js` — sample course data

## Run it
```bash
npm install
npm run dev
```
Then open the printed local URL. Try:
- `/` — Home
- `/courses` — Courses list
- `/course/react-101` and `/course/js-201` — dynamic course detail pages
- `/about` — About
